Instructions for running the svdfs
----------------------------------

Note: this software is compatible with Windows 7 and may also run on Windows 8/10 (though not tested fully)


Installation: 
1. Ensure you have JDK 1.7x installed and available in the path
2. Unzip the file into a folder (e.g c:\svdfs) 
3. Run InstallEldos.bat (as admin) to install Eldos drivers. restart the computer. 


Running local mode: 
In this mode, you will use the local slice stores 

1. Run the following in the order: StartMaster.bat, StartLocalStores, StartClient. 

This will start the master server, and 5 local slicestores, and then the file client. 

2. From the notification bar, you will notice a little icon (like a harddisk), right click and select mount. This will mount the virtual filesystem (e.g. T:\) 

3. Drag a file (any file) to the virtual drive. 

4. You can view the meta-data by accessing the webpage:  

http://localhost:9015/viewer/all_files

You can go to the slice stores storage directory to see the individual slices (in this demo, the IDA is configured to use 3/5 encoding). The storage directories are called testfs1, testfs2, etc.. To view the slices stored on S3, use any S3 browser to look at the contents of the bucket
You can 

Try deleting 1 or 2 slices. You should be still be able to open the file. Try deleting 3 slices, and you will see that the file is no more accessible. 

Note: you can change the port numbers used by changing the configuration files in the resources subfolder (such as MasterConfig.properties, SliceStoreConfig.properties, and svdsclient.properties). 


Note: You will notice that everytime your restart the file system, the directory is empty, because the script StartMaster.bat deletes the image file of meta data. You can comment out the the 3 delete commands if you want to override this behaviour.

Running hybrid mode: 
In this mode, you will start a mixture of local slice stores and some s3 slice stores

1. Edit the file in <installdir>\master\resources\s3SliceStores(sample) to edit the s3 configuration (the bucketname, credentials, region, etc. Change the numbering cnt to reflect number of buckets and for each bucket config, number accordingly).

2  Start the master server by running StartMaster.bat.  


Uninstallation
--------------

4. To uninstall, run InstallEldos.bat again. Restart your computer. 
5. Delete the folder (e.g. svdfs)


